from django.shortcuts import render

postts = [
    {
        "id": 1,
        "titulo": "post um"
    },
        {
        "id": 2,
        "titulo": "post dois"
    }
]

def posts(resquest):
    context = {
        "posts": postts
    }
    return render(resquest, 'listar_posts.html', context)

def detalhe_post(request, id):
    post = postts[id-1]
    return render(request, 'detalhe_post.html', {"post" : post})